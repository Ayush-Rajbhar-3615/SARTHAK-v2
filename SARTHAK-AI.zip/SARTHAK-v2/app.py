from flask import Flask, render_template, request, jsonify, send_from_directory
import requests
import os
import json

# load API key & model from config (config.py) or environment
try:
    from config import API_KEY, MODEL
except Exception:
    API_KEY = os.environ.get("OPENAI_API_KEY", "")
    MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")

if not API_KEY:
    raise RuntimeError("OpenAI API key not found. Set OPENAI_API_KEY env var or update config.py")

app = Flask(__name__, static_folder="static", template_folder="templates")

OPENAI_URL = "https://api.openai.com/v1/chat/completions"
HEADERS = {
    "Content-Type": "application/json",
    "Authorization": f"Bearer {API_KEY}"
}

def ask_sarthak(prompt):
    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": "You are SARTHAK AI, created by Ayush Rajbhar. Always stay respectful and helpful."},
            {"role": "user", "content": prompt}
        ],
        # optional: "max_tokens": 1024, "temperature": 0.7
    }
    try:
        resp = requests.post(OPENAI_URL, headers=HEADERS, data=json.dumps(payload), timeout=30)
        if resp.status_code != 200:
            return f"Backend Error: {resp.status_code} - {resp.text}"
        body = resp.json()
        # defensive access
        return body.get("choices", [{}])[0].get("message", {}).get("content", "No reply from model.")
    except requests.exceptions.RequestException as e:
        return f"Request error: {str(e)}"

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api", methods=["POST"])
def api():
    data = request.get_json(force=True)
    user_msg = data.get("message", "") if data else ""
    if not user_msg:
        return jsonify({"reply": "Please send a message in JSON: {\"message\":\"...\"}"}), 400
    reply = ask_sarthak(user_msg)
    return jsonify({"reply": reply})

# serve static favicon if needed (Flask will serve from /static by default)
@app.route("/favicon.ico")
def favicon():
    return send_from_directory(os.path.join(app.root_path, "static"),
                               "sarthak.png", mimetype="image/png")

if __name__ == "__main__":
    # host 0.0.0.0 for local network testing; set debug=False for production
    app.run(host="0.0.0.0", port=8000, debug=True)
