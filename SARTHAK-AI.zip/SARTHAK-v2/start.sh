#!/bin/bash
# start.sh - simple starter (make executable: chmod +x start.sh)
# optional: activate python venv here
cd "$(dirname "$0")"
# ensure env var is set, otherwise try config.py
# Example (uncomment to set inline):
# export OPENAI_API_KEY="sk-...."

python3 app.py
